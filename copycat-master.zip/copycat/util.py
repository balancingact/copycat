#!/usr/bin/python

############################# Various Utilites ##################################
#                                                                               #
#   Compilation of various useful python scripts. Organized in alphabetical     #
# order according to method name. Copy and paste, or import this library        #
#                                                                               #
# Author: J Lyons                                                               #
# Created: 3/30/2016                                                            #
# Last Update: 11/16/2016                                                       #
#                                                                               #
#################################################################################

try:
	import sys
	import zlib
	import json
	import struct
	import base64
	import urllib
	import smtplib
	import hashlib
	import urllib2
	import logging
	import datetime
	import traceback
	from email.mime.text import MIMEText
	from subprocess import Popen, PIPE, STDOUT
except ImportError:
	print(('\n' * 2).join(["Error importing a module:",
			'\t' + str(sys.exc_info()[1]), 'Install the module and try again.']))
	raise SystemExit(1)

def execute(cmd):
	"""
	Executes the given command.
	
	@type	cmd:	string
	@param	cmd:	Command to run in the shell (i.e. 'echo "util.py method execute example" >> test.txt')
	
	@raise	e:		If the command does not exit with a returncode of 0 the a RuntimeError is raised
	"""
	# Initiate the command
	p = Popen(cmd, shell=True, stdout=PIPE, stderr=PIPE)
	
	# Wait until the process finishes, and then get the status and/or error
	stdout_data, stderr_data = p.communicate()
	
	# Raise an error if the command exited with a non-zero exit code
	if p.returncode != 0:
		raise RuntimeError("%r failed(%s): %r" % (cmd, p.returncode, stderr_data.rstrip('\n').lstrip('\n')))
	
	return stdout_data

def debug_pretty(locals_dict, keys=[]):
	"""
	Get a pretty string of all the variables in scope.
	
	@type	locals_dict:	dict
	@param	locals_dict:	The dict of local variables (locals())
	@type	keys:			list
	@type	keys:			List of other keys to exclude
	
	@return					Pretty string
	"""
	return json.dumps(debug_nice(locals_dict, keys), indent=4)
def debug_nice(locals_dict, keys=[]):
	"""
	Get all variables in scope in a dict.
	
	@type	locals_dict:	dict
	@param	locals_dict:	The dict of local variables (locals())
	@type	keys:			list
	@type	keys:			List of other keys to exclude
	
	@return					Dict of local variables
	"""
	
	globals()['types'] = __import__('types')
	exclude_keys = ['copyright', 'credits', 'False',
					'True', 'None', 'Ellipsis', 'quit']
	exclude_valuetypes = [types.BuiltinFunctionType,
						  types.BuiltinMethodType,
						  types.ModuleType,
						  types.TypeType,
						  types.FunctionType]
	return {k: v.__repr__() for k,v in locals_dict.iteritems() if not
				(k in keys or
				 k in exclude_keys or
				 type(v) in exclude_valuetypes) and
				k[0] != '_'}

def send_get(url, args, logger=None):
	"""
	Send GET request to given url with the given args
	
	@type	url:	string
	@param	url:	URL to send GET request
	@type	args:	dict
	@param	args:	Args to be appended to the URL
					(i.e. {'key1': 'value1', 'key2': 'value2'} => 'http://localhost/test?key1=value1&key2=value2')
	@type	logger:	logger
	@param	logger:	Logger for logging. Defaults to None
	"""
	
	if logger:
		logger.debug('Querying url: "' + url + '" - args: "' + json.dumps(args) + '"')
	req = urllib2.Request(url + "?" + urllib.urlencode(args))
	
	resp = urllib2.urlopen(req)
	ret = resp.read()
	resp.close()
	return ret

def json_to_string(params):
	"""
	Translate dict to JSON GET string of args
	
	@type	params:	dict
	@param	params:	Dict of key-value pairs to be converted to a string
					(i.e. {'key1': 'value1', 'key2': 'value2'} => '?key1=value1&key2=value2')
	
	@return			String conversion of the dict (i.e. '?key1=value1&key2=value2')
	"""
	if params != "":
		ret = "?"
		for key, value in params.iteritems():
			ret += key + "=" + str(value) + "&"
		return urllib.urlencode(ret[:-1])
	else:
		return ""
	
def send_post(url, args, logger):
	"""
	Send POST request to given url with the given JSON args
	
	@type	url:	string
	@param	url:	URL to send POST request
	@type	args:	JSON viable dict
	@param	args:	Args to be POSTed. Must be JSON vialbe.
	@type	logger:	logger
	@param	logger:	Logger for logging. Defaults to None
	"""
	
	if logger:
		logger.debug('Querying url: "' + url + '" - args: "' + json.dumps(args) + '"')
	req = urllib2.Request(url, json.dumps(args), {'Content-Type': 'application/json'})
	
	resp = urllib2.urlopen(req)
	ret = json.loads(resp.read())
	resp.close()
	return ret

def encode(text, key):
	"""
	Encode a string against a given key and append a CRC32 checksum
	
	@type	text:	string
	@param	text:	Text to be encoded
	@type	key:	string
	@param	key:	Secret key to encode against
	
	@return			Encoded string
	"""
	text = '{}{}'.format(text, struct.pack('i', zlib.crc32(text)))
	
	enc = []
	for i in range(len(text)):
		key_c = key[i % len(key)]
		enc_c = chr((ord(text[i]) + ord(key_c)) % 256)
		enc.append(enc_c)
	
	return base64.urlsafe_b64encode("".join(enc))

def decode(encoded_text, key):
	"""
	Decode a string against a given key and verify the appended CRC32 checksum
	
	@type	text:	string
	@param	text:	Encoded text to be decoded
	@type	key:	string
	@param	key:	Secret key to decode with
	
	@return			Decoded string
	"""
	dec = []
	encoded_text = base64.urlsafe_b64decode(encoded_text)
	for i in range(len(encoded_text)):
		key_c = key[i % len(key)]
		dec_c = chr((256 + ord(encoded_text[i]) - ord(key_c)) % 256)
		dec.append(dec_c)
	
	dec = "".join(dec)
	checksum = dec[-4:]
	dec = dec[:-4]
	
	assert zlib.crc32(dec) == struct.unpack('i', checksum)[0], 'Decode Checksum Error'
	
	return dec

def sendEmail(receivers, subject, sender, body, log=None):
	"""
	Sends an email.
	
	@type	receivers:	list
	@param	receivers:	Email addresses for recipients of the email
	@type	subject:	string
	@param	subject:	Subject of the email
	@type	sender:		string
	@param	sender:		Email address of the sender
	@type	body:		string
	@param	body:		Content of the email
	@type	log:		logger
	@param	log:		If logging is desired, pass a logger
	"""
	
	emailMessage = MIMEText(body, 'html')
	emailMessage['Subject'] = subject
	emailMessage['From'] = sender
	emailMessage['To'] = ", ".join(receivers)
	
	smtpObj = smtplib.SMTP('gateway.byu.edu')
	smtpObj.sendmail(sender, receivers, emailMessage.as_string())
	smtpObj.quit()
	
	if log:
		log.info("Email sent to " + ", ".join(receivers))

if __name__ == '__main__':
	# Example of the execute method
	execute('echo "util.py method execute example" >> test.txt')
	
	#send_get('http://google.com', {'key': 'value'}, None)
	#send_post('http://google.com', {'key': 'value'}, None)
	
	key = "password"
	orig = "This is a test string"
	enc = encode(orig, key)
	print enc
	dec = decode(enc, key)
	print dec
	
	#sendEmail(["joshua.lyons@byu.edu"], "ERROR | util.py", "joshua.lyons@byu.edu", "There has been an error!!")
	
	# Set a few local variables
	t = "This"
	i = 1024
	j = {'one':1, 'two':2}
	a = {'d':j, 'c':None}
	d = datetime.datetime.now()
	logger = logging.getLogger("Util Logger")
	print debug_pretty(locals(), ['MIMEText', 'PIPE', 'STDOUT'])