import json
from records import A, NS, PTR

class Filter():
    """
    Class for handling and containing filter information.
    
    @type   fl:     dict
    @ivar   fl:     The filter information
    """
    filt = {}
    
    def __init__(self, fl):
        self.filt = fl
    
    def isUsed(self, agent):
        return agent in self.filt['agents']
    
    def getInfo(self):
        return self.filt
    
    def shouldAddString(self, record):
        if record[0] == 's' or record[1] == 's':
            rec = NS({'string': record})
            return self.shouldAdd(rec.getName(), rec.getIp())
        elif record[0] == 'h' or record[1] == 'h':
            rec = A({'string': record})
            return self.shouldAdd(rec.getAddr(), rec.getIp())
        elif record[0] == 'p' or record[1] == 'p':
            rec = PTR({'string': record})
            return self.shouldAdd(rec.getAddr(), rec.getIp())
    
    def shouldAddRecord(self, record):
        if isinstance(record, NS):
            return self.shouldAdd(record.getName(), record.getIp())
        else:
            return self.shouldAdd(record.getAddr(), record.getIp())
    
    def shouldAdd(self, name, ip):
        if 'name' in self.filt:
            if self.filt['name'] == name:
                if 'condition' in self.filt:
                    if 'ip' in self.filt['condition']:
                        cond = self.filt['condition']['ip']
                        if '*' in cond:
                            return ip[:len(cond)-1] == cond[:len(cond)-1]
                        else:
                            return cond == ip
                else:
                    return False
            else:
                return True
    
    def __str__(self):
        return json.dumps(filters, indent=4)
    